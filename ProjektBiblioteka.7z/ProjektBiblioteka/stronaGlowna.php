<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pl">

<head>
   <meta charset="UTF-8">
   <title>Książki online</title>
   <link rel="stylesheet" href="style.CSS">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>

<body>
<br>
<a style="position: absolute; top: 1%; right: 12%; " href="RejestracjaLog/zalogujSie.php">Wyloguj</a>
  <div id="obrazNaglowkowy">
    <img style="width: 25%" src="img/logo.jpg"><img style="width: 54%" src="img/naglowek.jpg">
  </div>
<br>
  <div>
    <button class="menu"><a id="pasekMenu">STRONA GŁÓWNA  </a></button>
    <button class="menu"><a id="pasekMenu" href="katalogKsiazek/katalogKsiazek.php">KATALOG KSIĄŻEK</a></button>
    <button class="menu"><a id="pasekMenu" href="mojeKonto.php">MOJE KONTO </a></button>
    <button class="menu"><a id="pasekMenu" href="ranking.php">RANKING </a></button>
    <?php
        if( $_SESSION["rola"] == 'admin') {
            echo "<button class='menu'><a id='pasekMenu' href='Gtunki/EdycjaGatunki.php'>GATUNKI </a></button>";
        }
    ?>
  </div>
<br>
  <div id="stronaCentrum">
    WITAJ DROGI CZYTELNIKU! <br> <h3><em>Przedstawiam tu dla ciebie 10 powodów, dla których warto czytać książki</em></h3>
    Nie ma wątpliwości, że czytanie wpływa w znaczącym stopniu na nasz umysł. Choć statystyki nie są pozytywne i pokazują, że coraz więcej osób zamiast papierowej lektury wybiera Internet jako podstawowe źródło informacji, bez wątpienia to właśnie czytanie książek pogłębia zasób słownictwa, uczy ortografii, interpunkcji, pozwala na dogłębne poznanie problemu, poszerza wiedzę. Czasami wystarczy kilka minut dziennie, by w ciągu roku przeczytać kilka wartościowych książek. Przedstawiamy 10 korzyści płynących z czytania.
    <br><br><em><strong>
    1. Większy zasób słownictwa
    <br><br></em></strong>
    Czytanie wzbogaca słownictwo, co znacznie pomaga w opisywaniu swoich uczuć i myśli. Ludziom często umyka jakiś wyraz lub chcą coś powiedzieć, ale nie potrafią ubrać tego w słowa. Na szczęście można nad tym pracować, a czytanie jest najlepszym ćwiczeniem . Warto czytać książki zarówno podczas nauki czytania, jak i wtedy, kiedy ta umiejętność została opanowana do perfekcji.
    <br><br><em><strong>
    2. Lepsza pamięć
    <br><br></em></strong>
    Czytanie książek to także doskonała stymulacja dla mózgu. Czytając, tworzymy w głowie obrazy, łączymy nową wiedzę z tym, co już jest nam znane. Podczas czytania lektury, neurony są nieustannie zmuszane do wysiłku, co przekłada się na lepszą pamięć.
    <br><br><em><strong>
    3. Redukcja stresu
    <br><br></em></strong>
    Dlaczego warto czytać książki? Czytanie działa uspokajająco. Jeżeli wybierzesz książkę, która naprawdę Cię interesuje, stres dnia codziennego odejdzie w zapomnienie. Książki biznesowe czy poradniki warto czytać rano, natomiast wieczorem, p rzed snem wybierać powieści — ułatwi nam to zasypianie.
    <br><br><em><strong>
    4. Pogłębianie wiedzy
    <br><br></em></strong>
    Ludzie, którzy czytają, są mądrzejsi. Nie bez powodu mówi się o kimś, kto posiada wartościową wiedzę, że jest „oczytany”. Książki pozwalają na poprawę wielu aspektów swojego życia — od biznesu, poprzez relacje z innymi, po psycho logię. Warto czytać książki, ponieważ to właśnie lektura sprawia, że człowiek poszerza swoje horyzonty i staje się jeszcze bardz iej inteligentny.
    <br><br><em><strong>
    5. Garść inspiracji
    <br><br></em></strong>
    Książki potrafią zainspirować. Czasami znajdujemy się w takim punkcie swojego życia, że nie wiemy, w którą stronę warto pójść. Dlaczego warto czytać książki? W lekturze może zainspirować wszystko — postawa głównego bohatera, odwiedzane miejsca, podejmowane decyzje, aktywności.
    <br><br><em><strong>
    6. Rozwijanie wrażliwości
    <br><br></em></strong>
    Czytanie książek rozwija wrażliwość na sztukę i na innych ludzi. Ludzie, którzy czytają, 3 razy częściej odwiedzają muzea, a 2 razy częściej sami malują, piszą lub fotografują. Dzięki książkom rozwija się także empatia. Angażujemy się w fikcję literacką i potrafimy postawić się na miejscu drugiego człowieka, a także go zrozumieć.
    <br><br><em><strong>
    7. Zwiększenie zdolności analitycznych
    <br><br></em></strong>
    Książki wpływają także na większe zdolności analityczne. Osoby, które czytają kryminały, wymagające rozwiązywania zagadek, analizowania faktów, stawiania tez, rozwijają w sobie zdolność krytycznego i analitycznego myśleni a. Warto czytać książki już od najmłodszych lat, aby zauważyć pozytywny wpływ czytania w dorosłym życiu.
    <br><br><em><strong>
    8. Poprawa pisania
    <br><br></em></strong>
    Częstsze sięganie po lekturę to także rozwijanie własnego stylu. Warto wybierać książki uznanych pisarzy, dzięki którym nauczymy się poprawności gramatycznej oraz ortograficznej. To jedna z najważniejszej korzyści, wynikającej z czytania książek, którą z pewnością doceni każdy dorosły, który już jako dziecko namiętnie czytał książki.
    <br><br><em><strong>
    9. Kształtowanie osobowości
    <br><br></em></strong>
    Dzięki czytaniu możemy postawić się w różnych sytuacjach i wyobrażać sobie, co zrobilibyśmy na miejscu bohatera. Otwieramy się tym samym na nowe doświadczenia czy wyzwania, rozszerzamy horyzonty, kształtując własną osobowość. Ponadto dziecko, czytające mądre powieści przygodowe, może nauczyć się pozytywnych zachowań, które w dorosłym życiu mogą nie raz uratować człowieka z opresji.
    <br><br><em><strong>
    10. Zaangażowanie w życie społeczne
    <br><br></em></strong>
    Według badań przeprowadzonych przez amerykańską agencję wspierającą sztukę — NEA — ludzie, którzy regularnie czytają, znacznie bardziej angażują się obywatelsko oraz kulturowo. Co więcej, czytelnicy mają większą swobodę i łatwość wypowiedzi, robią to w sposób bardziej elokwentny. Przekłada się to na większe szanse na osiągnięcie sukcesu w życiu, a także podnosi samoocenę.<br><br>
    <em><strong>Więc nie wahaj się ani chwili dłużej tylko przejdź do zakładki "katalog Książek" i wybierz coś dla siebie!</em></strong>
  </div>
<br>
  <div id="footer">
    <br>
    <img id="footer1" src="img/narodowa.jpg">
    <img id="footer2" src="img/towarzystwoLiterackie.jpg">
    <img id="footer3" src="img/ministerstwoKultury.jpg">
    <img id="footer4" src="img/wydawnictwoLiterackie.jpg">
    <h6>© 2019, Natalia Koć </h6>
  </div>

</body>

</html>
